package com.gonzales.jonathan;

//import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;
import android.support.design.widget.Snackbar;
//import android.content.Intent;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "LIFECYCLE";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.d(TAG, "onCreate() was called");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override
    protected void onStart() {
        Log.d(TAG, "onStart() was called");
        super.onStart();
    }

    @Override
    protected void onResume() {
        Log.d(TAG, "onResume() was called");
        super.onResume();
    }

    @Override
    protected void onPause() {
        Log.d(TAG, "onPause() was called");
        super.onPause();
    }

    @Override
    protected void onStop() {
        Log.d(TAG, "onStop() was called");
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        Log.d(TAG, "onDestroy() was called ");
        super.onDestroy();
    }

    @Override
    protected void onRestart() {
        Log.d(TAG, "onRestart() was called ");
        super.onRestart();
    }


    public void showToast(View view)
    {
        Toast.makeText(getApplicationContext(), "NEXT", Toast.LENGTH_SHORT).show();
//        switch (view.getId()) {
//            case R.id.button:
//                Toast.makeText(getApplicationContext(), "BACK", Toast.LENGTH_SHORT).show();
//                break;
//            case R.id.button2:
//                Toast.makeText(getApplicationContext(), "NEXT", Toast.LENGTH_SHORT).show();
//                break;
//        }
        //Intent intent = new Intent(MainActivity.this, ToActivity.class);
        //startActivity(intent);
    }

    public void showSnackbar(View view)
    {
        Snackbar.make(findViewById(android.R.id.content), "Welcome To Main Activity", Snackbar.LENGTH_LONG).show();
    }



}
